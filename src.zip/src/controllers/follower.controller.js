const followerService = require('../services/follower.service');
const { AppError, asyncWrapper } = require('../middleware/errorHandler');
const { preferencesSchema } = require('../validators/user.validators');

exports.followUser = asyncWrapper(async (req, res) => {
  await followerService.followUser(req.user.id, req.params.id);
  res.status(201).json({ status: 'success', message: 'Followed' });
});

exports.unfollowUser = asyncWrapper(async (req, res) => {
  await followerService.unfollowUser(req.user.id, req.params.id);
  res.json({ status: 'success', message: 'Unfollowed' });
});

exports.getFollowers = asyncWrapper(async (req, res) => {
  const followers = await followerService.getFollowers(req.params.id);
  res.json({ status: 'success', data: followers });
});

exports.getFollowing = asyncWrapper(async (req, res) => {
  const following = await followerService.getFollowing(req.params.id);
  res.json({ status: 'success', data: following });
});

exports.updatePreferences = asyncWrapper(async (req, res) => {
  const result = preferencesSchema.safeParse(req.body);
  if (!result.success) {
    throw new AppError(result.error.issues.map(i => i.message).join(', '), 400);
  }
  const updated = await followerService.updatePreferences(req.user.id, result.data);
  res.json({ status: 'success', data: updated });
});
