const userService = require('../services/user.service');
const { AppError, asyncWrapper } = require('../middleware/errorHandler');
const { updateMeSchema } = require('../validators/user.validators');

exports.getMe = asyncWrapper(async (req, res) => {
  const user = await userService.getMe(req.user.id);
  res.json({ status: 'success', data: user });
});

exports.updateMe = asyncWrapper(async (req, res) => {
  const result = updateMeSchema.safeParse(req.body);
  if (!result.success) {
    throw new AppError(result.error.issues.map(i => i.message).join(', '), 400);
  }
  const updatedUser = await userService.updateMe(req.user.id, result.data);
  res.json({ status: 'success', data: updatedUser });
});

exports.getUserById = asyncWrapper(async (req, res) => {
  const user = await userService.getUserById(req.params.id);
  if (!user) throw new AppError('User not found', 404);
  res.json({ status: 'success', data: user });
});
