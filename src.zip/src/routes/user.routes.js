const express = require('express');
const router = express.Router();
const userController = require('../controllers/user.controller');
const protect = require('../middleware/protect');

const followerController = require('../controllers/follower.controller');


/**
 * @swagger
 * /users/{id}/follow:
 *   post:
 *     tags: [Users]
 *     summary: Follow a user
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       201:
 *         description: Followed
 */
router.post('/:id/follow', protect, followerController.followUser);

/**
 * @swagger
 * /users/{id}/unfollow:
 *   delete:
 *     tags: [Users]
 *     summary: Unfollow a user
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200:
 *         description: Unfollowed
 */
router.delete('/:id/unfollow', protect, followerController.unfollowUser);

/**
 * @swagger
 * /users/{id}/followers:
 *   get:
 *     tags: [Users]
 *     summary: List followers of a user
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200:
 *         description: Followers list
 */
router.get('/:id/followers', followerController.getFollowers);

/**
 * @swagger
 * /users/{id}/following:
 *   get:
 *     tags: [Users]
 *     summary: List accounts a user follows
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200:
 *         description: Following list
 */
router.get('/:id/following', followerController.getFollowing);

/**
 * @swagger
 * /users/preferences:
 *   patch:
 *     tags: [Users]
 *     summary: Update notification preferences
 *     security: [{ bearerAuth: [] }]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               inApp: { type: object }
 *               email: { type: object }
 *     responses:
 *       200:
 *         description: Updated preferences
 */
router.patch('/preferences', protect, followerController.updatePreferences);


/**
 * @swagger
 * /users/me:
 *   get:
 *     tags: [Users]
 *     summary: Get current user's profile
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200:
 *         description: User profile
 */
router.get('/me', protect, userController.getMe);


/**
 * @swagger
 * /users/updateMe:
 *   patch:
 *     tags: [Users]
 *     summary: Update current user's profile
 *     security: [{ bearerAuth: [] }]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               username: { type: string }
 *               bio: { type: string }
 *               avatarKey: { type: string }
 *     responses:
 *       200:
 *         description: Updated profile
 */
router.patch('/updateMe', protect, userController.updateMe);

/**
 * @swagger
 * /users/{id}:
 *   get:
 *     tags: [Users]
 *     summary: Get public profile by ID
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200:
 *         description: Public profile
 */
router.get('/:id', userController.getUserById);

module.exports = router;
